Config = {}

Config.UseOxLib = true -- ox_lib = true, esx = false

Config.Armature = {
    [25] = 500,
    [50] = 1000,
    [75] = 1500,
    [100] = 2000
}

Config.MarkerCoords = {
    vec3(219.1104, -817.4422, 30.5655),
    vec3(212.5890, -818.9858, 30.5618)
}
