fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'STEFFONE'

shared_script '@es_extended/imports.lua'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

server_scripts {
    'server.lua',
}

client_scripts {
    'client.lua',
}


-- Bro is a open source why you just dump this..? ;)