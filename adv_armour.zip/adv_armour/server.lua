ESX.RegisterServerCallback('steffone:checkMoney', function(src, cb, price)
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer.getAccount('bank').money >= price then
        xPlayer.removeAccountMoney('bank', price)
        cb(true)
    else
        xPlayer.showNotification("You don't have enough money!")
        cb(false)
    end
end)