SIMPLE SCRIPT FOR SET ARMOUR ON THE GAME


To install it, just follow these steps:

- Go to server.cfg and ensure 'steffone_armour' is added.

- Restart the server.

- And enjoy!

Sorry but for the moment I won't translate this script because it is very very simple and I won't waste time with this script, in the next scripts I will make the locales table ;)

Or ... I don't optimize it because I need to publish something