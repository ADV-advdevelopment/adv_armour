ESX = exports["es_extended"]:getSharedObject()

local function giveArmor(value)
    local ped = cache.ped
    if not Config.Armature[value] then
        SetPedArmour(ped, 0)
        ESX.ShowNotification("You removed your vest")
        return
    end

    ESX.TriggerServerCallback('steffone:checkMoney', function(success)
        if success then
            SetPedArmour(ped, value)
            ESX.ShowNotification(("You received: %d%% and paid: %s"):format(value, Config.Armature[value]))
        end
    end, Config.Armature[value])
end

CreateThread(function()
    for i, v in ipairs(Config.MarkerCoords) do
        TriggerEvent('gridsystem:registerMarker', {
            name = 'steffone_armour' .. i,
            pos = v,
            scale = vec3(1, 1, 1),
            msg = 'Press [E] to interact',
            control = 'E',
            type = 1,
            color = { r = 130, g = 120, b = 110 },
            action = function()
                local menu = Config.UseOxLib and 'steffone:menuoxlib' or 'steffone:menudefault'
                TriggerEvent(menu)
            end
        })
    end
end)

RegisterNetEvent("steffone:menudefault", function()
    local elements = {}
    for value in pairs(Config.Armature) do
        table.insert(elements, { label = ("Get armor %d"):format(value), name = tostring(value) })
    end
    table.insert(elements, { label = "Remove vest", name = "0" })

    ESX.UI.Menu.Open("default", GetCurrentResourceName(), "menu_armour", {
        title = "Select armor",
        align = 'top-left',
        elements = elements
    }, function(data, menu)
        giveArmor(tonumber(data.current.name))
    end, function(data, menu)
        menu.close()
    end)
end)

RegisterNetEvent("steffone:menuoxlib", function()
    local options = {}
    for value in pairs(Config.Armature) do
        table.insert(options, {
            title = ("Get Vest - %d"):format(value),
            icon = "shield-halved",
            onSelect = function() giveArmor(value) end
        })
    end
    table.insert(options, {
        title = "Remove vest",
        icon = "x",
        onSelect = function() giveArmor(0) end
    })

    lib.registerContext({
        id = 'steffone_armour',
        title = 'Get Armor',
        options = options
    })
    lib.showContext('steffone_armour')
end)